"use strict";
var firebaseConfig = {
  apiKey: "AI---------------------------G0",
    authDomain: "ec--------------------------p.com",
    projectId: "ec----------------dev",
    storageBucket: "ec-------------------------com",
    messagingSenderId: "60----------4",
    appId: "1--------------------------------------b",
    measurementId: "G------------2"
};
firebase.initializeApp(firebaseConfig);
firebase.analytics();
