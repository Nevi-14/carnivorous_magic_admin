If you are a new user before running the website, You just need to configure the website using the given documentation with your server URL, jwt key, etc.

Without configuration, the website will not work.

First, need to set up the admin panel.

Then you need to go to website configuration, follow by documentation step.

Thank you!
