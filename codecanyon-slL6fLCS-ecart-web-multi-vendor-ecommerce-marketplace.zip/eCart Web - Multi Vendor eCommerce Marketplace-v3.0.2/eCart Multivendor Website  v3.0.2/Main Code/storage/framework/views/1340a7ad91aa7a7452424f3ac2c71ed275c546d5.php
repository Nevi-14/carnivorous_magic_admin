<?php $__env->startSection('title', __('Not Found')); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', __('Not Found')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shreesoftech/Desktop/eCart Web - Multi Vendor eCommerce Marketplace-v3.0.1/eCart Multivendor Website  v3.0.1/Main Code/resources/views/errors/404.blade.php ENDPATH**/ ?>