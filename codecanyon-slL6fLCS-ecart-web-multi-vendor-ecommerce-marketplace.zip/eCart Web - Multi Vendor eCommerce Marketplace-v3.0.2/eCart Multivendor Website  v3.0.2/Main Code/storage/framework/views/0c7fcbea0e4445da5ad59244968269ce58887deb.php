
<?php if(Cache::has('offers') && is_array(Cache::get('offers')) && count(Cache::get('offers'))): ?>
<?php $__currentLoopData = Cache::get('offers'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(isset($o->image) && trim($o->image) !== ""): ?>
<div class="main-content">
   
    <div class="container-fluid">
        <div class="px-2 py-4 px-md-4 py-md-3 bg-white shadow-sm rounded">
            <div class="col-md-12">
                <div class="banner_box_content">
                    <img class="lazy" data-original="<?php echo e($o->image); ?>" alt="ad-1">
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /home/shreesoftech/Desktop/eCart Web - Multi Vendor eCommerce Marketplace-v3.0.1/eCart Multivendor Website  v3.0.1/Main Code/resources/views/themes/eCart/parts/offers.blade.php ENDPATH**/ ?>