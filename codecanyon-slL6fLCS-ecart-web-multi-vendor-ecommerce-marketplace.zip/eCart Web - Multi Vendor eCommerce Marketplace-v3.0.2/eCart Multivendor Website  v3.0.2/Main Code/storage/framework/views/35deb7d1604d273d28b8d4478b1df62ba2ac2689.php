<?php $__env->startSection('title', __('Server Error')); ?>
<?php $__env->startSection('code', '500'); ?>
<?php $__env->startSection('message', __('Server Error')); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shreesoftech/Desktop/eCart Web - Multi Vendor eCommerce Marketplace-v3.0.1/eCart Multivendor Website  v3.0.1/Main Code/resources/views/errors/500.blade.php ENDPATH**/ ?>